import React, { useState } from 'react';
import { 
  Check, 
  ChevronDown, 
  Sparkles, 
  ShieldCheck, 
  Heart, 
  Zap, 
  Smartphone, 
  Tablet, 
  Monitor, 
  Languages, 
  Send, 
  X, 
  Phone, 
  User, 
  MapPin, 
  CheckCircle2,
  FlaskConical,
  Gift,
  Flame,
  Snowflake,
  Coffee,
  Activity
} from 'lucide-react';

interface FAQ {
  q: string;
  a: string;
  qKr?: string;
  aKr?: string;
}

const faqs: FAQ[] = [
  {
    q: 'Có thể uống khi bụng đói (chưa ăn sáng) không?',
    qKr: '공복(아침 식전)에 마셔도 되나요?',
    a: 'Trà nhân sâm Gwi-Han-Saeng là thực phẩm chế biến thông thường, không phải thực phẩm chức năng gây kích ứng, nên bạn có thể thưởng thức vào bất kỳ thời điểm nào trong ngày.',
    aKr: '귀한생 인삼차는 자극적인 건강기능식품이 아닌 일반 가공식품이므로, 하루 중 언제라도 편안하게 드실 수 있습니다.'
  },
  {
    q: 'Trà có sử dụng phụ gia nhân tạo để khử vị đắng không?',
    qKr: '쓴맛을 없애기 위해 인공 첨가물을 사용했나요?',
    a: 'Không! Qua nhiều năm nghiên cứu, chúng tôi sử dụng công nghệ phối trộn thảo mộc tự nhiên để loại bỏ vị đắng mà KHÔNG dùng phụ gia hóa học độc hại.',
    aKr: '아닙니다! 다년간의 연구를 통해 유해 화학 첨가물 없이 순수 천연 허브 배합 기술만으로 쓴맛을 잡았습니다.'
  },
  {
    q: 'Có giới hạn liều lượng uống mỗi ngày không?',
    qKr: '하루 권장 섭취량이나 제한이 있나요?',
    a: 'Sản phẩm được làm từ 100% thành phần nguồn gốc tự nhiên an toàn, bạn có thể uống theo nhu cầu và sở thích hàng ngày mà không lo quá liều.',
    aKr: '100% 안전한 천연 원료로 만들어져 과다 복용 걱정 없이 일상적인 기호에 맞춰 편하게 드실 수 있습니다.'
  },
  {
    q: 'Không pha với nước mà ăn trực tiếp dạng bột được không?',
    qKr: '물에 타지 않고 분말 그대로 직접 섭취해도 되나요?',
    a: 'Sản phẩm có hương vị thơm ngọt nhẹ, dễ tan. Bạn có thể hòa tan vào nước ấm/lạnh hoặc uống trực tiếp tùy theo sở thích!',
    aKr: '은은한 단맛과 고운 입자로 물 없이 직접 드셔도 사르르 녹아 맛있게 드실 수 있습니다!'
  }
];

export default function App() {
  const [viewMode, setViewMode] = useState<'mobile' | 'container' | 'full'>('container');
  const [showKorean, setShowKorean] = useState<boolean>(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [selectedProduct, setSelectedProduct] = useState<string>('combo-3');
  const [orderSubmitted, setOrderSubmitted] = useState<boolean>(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    note: ''
  });

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setOrderSubmitted(true);
    setTimeout(() => {
      setTimeout(() => {
        setIsModalOpen(false);
        setOrderSubmitted(false);
        setFormData({ name: '', phone: '', address: '', note: '' });
      }, 2500);
    }, 400);
  };

  return (
    <div className="min-h-screen bg-slate-100 font-sans text-slate-800 antialiased selection:bg-orange-200">
      {/* Top Preview Control Bar */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs px-4 py-2.5">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-orange-600 text-sm tracking-tight flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-orange-500" />
              貴翰生 귀한생 (Gwi-Han-Saeng)
            </span>
            <span className="text-xs text-slate-400">|</span>
            <span className="text-xs font-medium text-slate-600 hidden sm:inline">
              맥락 맞춤형 10장 사진 배치 완료
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Viewport switcher */}
            <div className="flex items-center bg-slate-100 rounded-lg p-0.5 text-xs font-medium text-slate-600">
              <button
                type="button"
                onClick={() => setViewMode('mobile')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-all ${
                  viewMode === 'mobile'
                    ? 'bg-white text-orange-600 shadow-xs font-semibold'
                    : 'hover:text-slate-900'
                }`}
                title="스마트폰 화면 뷰 (390px)"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span className="hidden md:inline">390px</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('container')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-all ${
                  viewMode === 'container'
                    ? 'bg-white text-orange-600 shadow-xs font-semibold'
                    : 'hover:text-slate-900'
                }`}
                title="원본 상세페이지 규격 (640px)"
              >
                <Tablet className="w-3.5 h-3.5" />
                <span>640px (원본)</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('full')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-all ${
                  viewMode === 'full'
                    ? 'bg-white text-orange-600 shadow-xs font-semibold'
                    : 'hover:text-slate-900'
                }`}
                title="전체 화면 뷰 (100%)"
              >
                <Monitor className="w-3.5 h-3.5" />
                <span className="hidden md:inline">100%</span>
              </button>
            </div>

            {/* Korean translation helper */}
            <button
              type="button"
              onClick={() => setShowKorean(!showKorean)}
              className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-lg border transition-colors ${
                showKorean
                  ? 'bg-orange-50 border-orange-300 text-orange-700'
                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
              title="한국어 번역 가이드 표시/숨김"
            >
              <Languages className="w-3.5 h-3.5" />
              <span>{showKorean ? '한국어 숨김' : '한국어 번역 가이드'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="py-6 px-2 sm:px-4 flex justify-center">
        <div
          className={`transition-all duration-300 w-full bg-white shadow-xl rounded-2xl overflow-hidden border border-slate-200/80 ${
            viewMode === 'mobile'
              ? 'max-w-[390px]'
              : viewMode === 'container'
              ? 'max-w-[640px]'
              : 'max-w-4xl'
          }`}
        >
          {/* 1. Hero Banner */}
          <section className="bg-gradient-to-br from-[#ff9f1c] via-[#f77f00] to-[#ffbf69] text-white p-7 text-center relative overflow-hidden">
            <div className="absolute -right-12 -top-12 w-40 h-40 bg-white/10 rounded-full blur-2xl pointer-events-none" />
            <div className="relative z-10">
              <span className="inline-block bg-[#e63946] text-white text-xs md:text-sm font-bold px-3.5 py-1 rounded-full mb-3 shadow-xs tracking-wide">
                Bộ Quà Tặng Mới {showKorean && <span className="opacity-90 font-normal">· 신규 선물세트</span>}
              </span>
              <h1 className="text-2xl md:text-3xl font-extrabold leading-tight tracking-tight mb-2.5">
                Trà Nhân Sâm Gwi-Han-Saeng
                <br />
                <span className="font-semibold text-amber-100 text-xl md:text-2xl">
                  (귀한생 인삼차)
                </span>
              </h1>
              <p className="text-sm md:text-base text-amber-50 font-medium max-w-md mx-auto leading-relaxed">
                KHÔNG CÒN VỊ ĐẮNG! Thức uống dinh dưỡng hoàn hảo cho cả gia đình
              </p>
              {showKorean && (
                <p className="text-xs text-orange-950/80 bg-white/30 backdrop-blur-xs rounded-md py-1 px-2.5 mt-2 max-w-sm mx-auto">
                  쓴맛 ZERO! 온 가족을 위한 완벽한 데일리 영양 차
                </p>
              )}
            </div>
          </section>

          {/* Photo 1: HERO IMAGE (image_bcbc7a65.png) - 맨 끝에서 3번째 사진을 맨 첫번째로 배치 */}
          <figure className="relative m-0 bg-amber-50">
            <img
              src="/assets/aistudio/image_bcbc7a65.png"
              alt="Người phụ nữ rạng rỡ cầm gói Trà Nhân Sâm Gwi-Han-Saeng 귀한생"
              className="w-full h-auto block object-cover"
            />
            <figcaption className="bg-white/95 px-5 py-3 text-center text-xs md:text-sm font-semibold text-slate-800 border-t border-slate-100 flex items-center justify-between gap-2 shadow-2xs">
              <span>✨ Trà Nhân Sâm Gwi-Han-Saeng – Thức uống dinh dưỡng cho cả gia đình</span>
              {showKorean && <span className="text-[11px] text-orange-600 font-normal shrink-0">온 가족을 위한 프리미엄 인삼차</span>}
            </figcaption>
          </figure>

          {/* Official Distributor Notice */}
          <section className="p-7 md:p-9 bg-slate-50 border-b border-slate-200/60 text-center">
            <p className="text-xs font-bold text-orange-600 tracking-wider uppercase mb-1">
              KOREAN PREMIUM QUALITY
            </p>
            <h2 className="text-lg md:text-xl font-extrabold text-slate-800 mb-2">
              Nhà Phân Phối Chính Thức Gwi-Han-Saeng
            </h2>
            {showKorean && (
              <p className="text-xs text-slate-500 font-medium mb-1">
                [귀한생 인삼차 공식 유통 안내]
              </p>
            )}
            <p className="text-sm text-slate-600 font-medium mb-3">
              Cuộc sống khỏe mạnh và đẳng cấp dành cho bạn
            </p>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200/70 shadow-2xs max-w-lg mx-auto">
              <p className="text-xs text-slate-500 leading-relaxed">
                Được nghiên cứu & phát triển với sự hỗ trợ từ <strong>Bộ Khoa học & ICT</strong> và <strong>Bộ SME Hàn Quốc</strong>, sử dụng nguyên liệu thiên nhiên cao cấp.
              </p>
              {showKorean && (
                <p className="text-[11px] text-slate-400 mt-1 border-t border-slate-100 pt-1">
                  대한민국 과학기술정보통신부 및 중소벤처기업부 지원 연구개발 프리미엄 천연 원료 사용
                </p>
              )}
            </div>
          </section>

          {/* Photo 2: Official Gift Set Box & 3 Pouches (image_0d311a3c.png) */}
          <figure className="relative m-0 bg-white border-b border-slate-200/60">
            <img
              src="/assets/aistudio/image_0d311a3c.png"
              alt="Hộp quà cao cấp và 3 túi trà Gwi-Han-Saeng 귀한생"
              className="w-full h-auto block object-cover"
            />
            <figcaption className="bg-white px-5 py-3 text-center text-xs md:text-sm font-semibold text-slate-700 border-t border-slate-100">
              🌿 Bộ Quà Tặng Trà Nhân Sâm Cao Cấp Gwi-Han-Saeng (귀한생 정품 기프트 세트)
              {showKorean && <span className="block text-[11px] text-orange-600 font-normal mt-0.5">당신의 소중하고 품격 있는 웰-라이프를 위한 프리미엄 기프트 박스</span>}
            </figcaption>
          </figure>

          {/* 3 Options Feature Section */}
          <section className="p-6 md:p-8 border-b border-slate-200/60">
            <div className="text-center mb-6">
              <span className="text-xs font-bold text-orange-500 tracking-wider uppercase">
                WHY GWI-HAN-SAENG?
              </span>
              <h2 className="text-xl md:text-2xl font-bold text-slate-900 mt-1 mb-2">
                Tại sao nên chọn Trà Nhân Sâm Gwi-Han-Saeng?
              </h2>
              <p className="text-sm text-slate-500 max-w-md mx-auto">
                3 Dòng sản phẩm chuyên biệt giải quyết mọi lo âu sức khỏe!
              </p>
              {showKorean && (
                <p className="text-xs text-orange-600 mt-0.5">
                  건강 고민에 맞춘 3가지 맞춤형 프리미엄 라인업
                </p>
              )}
            </div>

            {/* Photo 3: 3 Lines Showcase on Stone Pedestals (image_0ada1f8c.png) */}
            <figure className="relative m-0 rounded-2xl overflow-hidden mb-6 border border-slate-200 shadow-sm bg-white">
              <img
                src="/assets/aistudio/image_0ada1f8c.png"
                alt="3 dòng sản phẩm Energy, Core Fit, Beauty trên bục đá cùng ly trà và nhân sâm lát"
                className="w-full h-auto block object-cover"
              />
              <figcaption className="p-3.5 bg-white text-center text-xs md:text-sm font-semibold text-slate-700 border-t border-slate-100">
                ✨ 3 Dòng chuyên biệt: Energy Charge (Xanh lá) · Core Fit (Tím) · Inner Beauty (Hồng)
              </figcaption>
            </figure>

            {/* Synergy Cards */}
            <div className="space-y-4">
              {/* Card 1 */}
              <div className="bg-white border border-slate-200/80 hover:border-orange-300 rounded-xl p-5 shadow-xs transition-all">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-orange-600 bg-orange-100/80 px-2.5 py-0.5 rounded-md">
                    01. Miễn Dịch {showKorean && '· 면역 활력'}
                  </span>
                  <Zap className="w-4 h-4 text-orange-500" />
                </div>
                <div className="text-base font-bold text-slate-900 mb-1.5 flex items-center gap-2">
                  <span>ENERGY CHARGE</span>
                  <span className="text-xs font-medium text-slate-400 font-mono">(에너지 차지)</span>
                </div>
                <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                  Sự kết hợp giữa Nhân sâm tuyển chọn và rễ Cát Cánh mang lại hương vị đậm đà, giúp thư giãn và phục hồi thể trạng suy nhược.
                </p>
                {showKorean && (
                  <p className="text-[11px] text-slate-400 mt-1.5 bg-slate-50 p-2 rounded-lg">
                    엄선된 인삼과 도라지(길경) 배합으로 깊고 부드러운 풍미, 기력 회복 및 피로 해소.
                  </p>
                )}
              </div>

              {/* Card 2 */}
              <div className="bg-white border border-slate-200/80 hover:border-orange-300 rounded-xl p-5 shadow-xs transition-all">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-100/80 px-2.5 py-0.5 rounded-md">
                    02. Sức Mạnh Cơ Bắp {showKorean && '· 근력 & 활기'}
                  </span>
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="text-base font-bold text-slate-900 mb-1.5 flex items-center gap-2">
                  <span>CORE FIT</span>
                  <span className="text-xs font-medium text-slate-400 font-mono">(코어 핏)</span>
                </div>
                <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                  Bổ sung chiết xuất Rau Răm & Cỏ Cỏ May, tăng cường sức sống và sinh lực khỏe mạnh cho cơ thể mệt mỏi sau tập luyện hoặc làm việc.
                </p>
                {showKorean && (
                  <p className="text-[11px] text-slate-400 mt-1.5 bg-slate-50 p-2 rounded-lg">
                    운동 전후나 격무 후 지친 신체에 활력과 에너지를 채워주는 최적의 허브 포뮬러.
                  </p>
                )}
              </div>

              {/* Photo 4: Fit & Active Lifestyle - Matches Core Fit (image_fc034baf.png) */}
              <div className="bg-slate-50 border border-slate-200/80 rounded-2xl overflow-hidden p-3 shadow-2xs">
                <figure className="relative m-0 rounded-xl overflow-hidden bg-white">
                  <img
                    src="/assets/aistudio/image_fc034baf.png"
                    alt="Người tập thể thao bổ sung năng lượng với bình trà Gwi-Han-Saeng 귀한생"
                    className="w-full h-auto block object-cover"
                  />
                  <figcaption className="p-3 bg-white text-center text-xs md:text-sm font-semibold text-slate-800 border-t border-slate-100">
                    💪 CORE FIT & ENERGY – Phục hồi thể lực và duy trì sức bền sau tập luyện & làm việc
                    {showKorean && <span className="block text-[11px] text-orange-600 font-normal mt-0.5">운동 전후 간편하게 마시는 데일리 활력 부스터</span>}
                  </figcaption>
                </figure>
              </div>

              {/* Card 3 */}
              <div className="bg-white border border-slate-200/80 hover:border-orange-300 rounded-xl p-5 shadow-xs transition-all">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-rose-600 bg-rose-100/80 px-2.5 py-0.5 rounded-md">
                    03. Làn Da & Inner Beauty {showKorean && '· 이너뷰티'}
                  </span>
                  <Heart className="w-4 h-4 text-rose-500" />
                </div>
                <div className="text-base font-bold text-slate-900 mb-1.5 flex items-center gap-2">
                  <span>INNER BEAUTY</span>
                  <span className="text-xs font-medium text-slate-400 font-mono">(이너 뷰티)</span>
                </div>
                <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                  Giữ trọn sự thanh khiết của Nhân sâm và thảo mộc, mang lại sức sống tự nhiên và làn da rạng rỡ từ bên trong.
                </p>
                {showKorean && (
                  <p className="text-[11px] text-slate-400 mt-1.5 bg-slate-50 p-2 rounded-lg">
                    인삼과 전통 식물성 추출물로 맑은 생기와 건강한 피부 컨디션을 돕는 이너뷰티 티.
                  </p>
                )}
              </div>
            </div>
          </section>

          {/* 30 Years Research Section */}
          <section className="p-6 md:p-8 bg-slate-50/80 border-b border-slate-200/60">
            <div className="text-center mb-5">
              <span className="text-xs font-bold text-orange-500 tracking-wider uppercase">
                RESEARCH & DEVELOPMENT
              </span>
              <h2 className="text-xl md:text-2xl font-bold text-slate-900 mt-1 mb-2">
                30 Năm Nghiên Cứu Chuyên Sâu
              </h2>
              <p className="text-xs md:text-sm text-slate-600 max-w-md mx-auto">
                Hợp tác cùng các chuyên gia nghiên cứu thực phẩm 30 năm kinh nghiệm tại <strong>Viện Nghiên Cứu E-Room Life Science (이룸생명과학 연구소)</strong>.
              </p>
            </div>

            <div className="bg-orange-50/70 border border-orange-200/80 rounded-xl p-4 md:p-5 my-5 text-center">
              <FlaskConical className="w-5 h-5 text-orange-600 mx-auto mb-2" />
              <p className="text-xs md:text-sm font-semibold text-slate-800 leading-relaxed">
                Chúng tôi đã dành hàng ngàn giờ thử nghiệm để loại bỏ vị đắng đặc trưng của nhân sâm, mang đến hương vị trà nhân sâm thơm ngon, dễ uống nhất!
              </p>
              {showKorean && (
                <p className="text-[11px] text-orange-900/80 mt-1.5">
                  수천 시간의 테스팅을 거쳐 특유의 쓴맛을 완전히 제거하고, 누구나 맛있게 즐기는 부드러운 맛을 완성했습니다.
                </p>
              )}
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-3 gap-2.5 my-6">
              <div className="bg-white border border-slate-200/70 p-3.5 rounded-xl text-center shadow-2xs">
                <div className="text-lg md:text-xl font-extrabold text-orange-600 font-mono tabular-nums">
                  12,960
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Giờ kiểm tra nguyên liệu
                </div>
                {showKorean && <div className="text-[10px] text-slate-400">원료 검수 시간</div>}
              </div>

              <div className="bg-white border border-slate-200/70 p-3.5 rounded-xl text-center shadow-2xs">
                <div className="text-lg md:text-xl font-extrabold text-orange-600 font-mono tabular-nums">
                  188 Lần
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Điều chỉnh tỷ lệ
                </div>
                {showKorean && <div className="text-[10px] text-slate-400">배합비 조정 횟수</div>}
              </div>

              <div className="bg-white border border-slate-200/70 p-3.5 rounded-xl text-center shadow-2xs">
                <div className="text-lg md:text-xl font-extrabold text-orange-600 font-mono tabular-nums">
                  56 Lần
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Thử nghiệm mẫu
                </div>
                {showKorean && <div className="text-[10px] text-slate-400">샘플 시음 테스트</div>}
              </div>
            </div>

            {/* Photo 5: 3 Pouches R&D Result (image_88fd50b5.png) */}
            <figure className="relative m-0 rounded-2xl overflow-hidden my-6 border border-slate-200 shadow-sm bg-amber-50">
              <img
                src="/assets/aistudio/image_88fd50b5.png"
                alt="Bộ 3 gói trà nhân sâm 귀한생 - FOR SEASON HOT & COOL HEALTH DRINK"
                className="w-full h-auto block object-cover"
              />
              <figcaption className="p-3 bg-white text-center text-xs md:text-sm font-semibold text-slate-700 border-t border-slate-100 flex items-center justify-center gap-2">
                <span className="text-orange-600 flex items-center gap-1 font-bold">
                  <Flame className="w-3.5 h-3.5 text-orange-500" /> Nóng & <Snowflake className="w-3.5 h-3.5 text-blue-500" /> Lạnh
                </span>
                <span>· Kết quả của 30 năm nghiên cứu thảo mộc Hàn Quốc</span>
              </figcaption>
            </figure>

            <div className="text-center pt-2">
              <h3 className="text-sm md:text-base font-bold text-slate-800">
                Dù nguyên liệu tốt đến đâu, nếu quá đắng thì có khác gì Cà Phê?
              </h3>
              <p className="text-xs text-slate-500 mt-1.5">
                Gwi-Han-Saeng lưu giữ trọn vẹn dưỡng chất tốt nhất cùng hương vị thanh ngọt dễ chịu.
              </p>
              {showKorean && (
                <p className="text-[11px] text-slate-400 mt-1">
                  아무리 좋은 성분도 쓰면 손이 안 갑니다. 귀한생은 최상의 영양과 부드러운 은은한 단맛을 담았습니다.
                </p>
              )}
            </div>
          </section>

          {/* Check Point Section: Coffee Replacement */}
          <section className="p-6 md:p-8 border-b border-slate-200/60">
            <h2 className="text-xl md:text-2xl font-bold text-center text-slate-900 mb-5">
              Tại Sao Nên Thay Cà Phê Bằng Trà Nhân Sâm?
            </h2>
            {showKorean && (
              <p className="text-center text-xs text-orange-600 -mt-3 mb-5">
                왜 커피 대신 귀한생 인삼차로 바꿔야 할까요?
              </p>
            )}

            {/* Photo 6: Flatlay Hot & Cold with Ginseng Root (image_1daa354d.png) */}
            <figure className="relative m-0 rounded-2xl overflow-hidden mb-6 bg-slate-50 border border-slate-200 shadow-sm">
              <img
                src="/assets/aistudio/image_1daa354d.png"
                alt="Ly trà nóng, ly trà đá và nhân sâm củ nguyên chất - Giải pháp thay thế cà phê hoàn hảo"
                className="w-full h-auto block object-cover"
              />
              <figcaption className="p-3.5 bg-white text-center text-xs md:text-sm font-semibold text-slate-800 border-t border-slate-100 flex items-center justify-between">
                <span>☕ ➔ 🍵 Thay thế cà phê mỗi ngày: Không lo Caffeine – Uống Nóng & Uống Lạnh</span>
                {showKorean && <span className="text-[11px] text-orange-600 font-normal">카페인 없는 건강한 커피 대용차</span>}
              </figcaption>
            </figure>

            <ul className="space-y-3 my-4">
              {[
                {
                  vi: 'Trà sức khỏe loại bỏ 100% vị đắng khó chịu',
                  kr: '특유의 불쾌한 쓴맛 100% 제거'
                },
                {
                  vi: 'Sự kết hợp hoàn hảo giữa 3 loại nguyên liệu thảo mộc cao cấp',
                  kr: '3가지 엄선된 프리미엄 허브 시너지 배합'
                },
                {
                  vi: 'Bao bì thiết kế tinh tế, sang trọng – Rất thích hợp làm quà tặng',
                  kr: '고급스러운 패키지 디자인으로 품격 있는 선물용 최적화'
                },
                {
                  vi: 'Nạp lại năng lượng cho cơ thể mệt mỏi sau ngày dài',
                  kr: '지친 현대인의 몸과 마음에 편안한 활력 충전'
                },
                {
                  vi: 'Uống Nóng vào mùa đông, uống Lạnh vào mùa hè!',
                  kr: '겨울엔 따뜻한 차로, 여름엔 시원한 아이스티로 사계절 음용'
                },
                {
                  vi: 'Không lo Caffeine! (Lượng Caffeine ~ 0%)',
                  kr: '카페인 걱정 제로! (카페인 함량 약 0%)'
                },
                {
                  vi: 'Pha chế cực nhanh chỉ với 1 muỗng/1 gói, không tốn thời gian chờ đợi!',
                  kr: '스틱 1포로 찬물/따뜻한 물에 바로 녹는 간편한 음용'
                }
              ].map((item, idx) => (
                <li key={idx} className="flex items-start gap-3 bg-slate-50/70 p-3 rounded-lg border border-slate-100">
                  <div className="w-5 h-5 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                  </div>
                  <div className="text-xs md:text-sm text-slate-700 leading-snug">
                    <span className="font-medium">{item.vi}</span>
                    {showKorean && (
                      <span className="block text-[11px] text-slate-400 mt-0.5">
                        ↳ {item.kr}
                      </span>
                    )}
                  </div>
                </li>
              ))}
            </ul>

            {/* Photo 7: Warm Morning Tea / Cozy Cardigan Model (image_c447c03f.png) */}
            <div className="mt-6 bg-amber-50/50 rounded-2xl p-3 border border-orange-200/70">
              <figure className="relative m-0 rounded-xl overflow-hidden bg-white shadow-2xs">
                <img
                  src="/assets/aistudio/image_c447c03f.png"
                  alt="Người phụ nữ thưởng thức trà nhân sâm ấm buổi sáng thay thế cà phê"
                  className="w-full h-auto block object-cover"
                />
                <figcaption className="p-3 bg-white text-center text-xs md:text-sm font-semibold text-slate-800 border-t border-slate-100 flex items-center justify-between">
                  <span>☀️ Khởi đầu ngày mới nhẹ nhàng với một tách trà nhân sâm ấm</span>
                  {showKorean && <span className="text-[11px] text-orange-600 font-normal">따뜻한 차 한 잔으로 차분하고 맑은 아침</span>}
                </figcaption>
              </figure>
            </div>
          </section>

          {/* Saponin 150mg & High Quality Red Ginseng (Dark Section) */}
          <section className="bg-slate-900 text-white p-7 md:p-9 text-center border-b border-slate-800">
            <span className="text-xs font-bold text-amber-400 tracking-widest uppercase">
              HÀM LƯỢNG SAPONIN CAO
            </span>
            <h2 className="text-2xl md:text-3xl font-extrabold text-white mt-2 mb-1">
              Chứa 150mg Saponin
            </h2>
            <p className="text-xs md:text-sm text-slate-300">
              Chiết xuất Nhân sâm 6 năm tuổi Hàn Quốc
            </p>
            {showKorean && (
              <p className="text-xs text-amber-300/80 mt-1">
                6년근 고려홍삼/인삼 추출 150mg 고함량 사포닌 함유
              </p>
            )}

            <div className="my-5 p-4 bg-white/10 backdrop-blur-md rounded-xl text-xs md:text-sm text-slate-200 border border-white/10 leading-relaxed max-w-lg mx-auto">
              Giữ trọn các hoạt chất Ginsenoside (Rg1, Rb1, Rg3) giúp điều hòa oxy trong cơ thể, giảm mệt mỏi và duy trì năng lượng cân bằng.
              {showKorean && (
                <div className="border-t border-white/10 pt-2 mt-2 text-[11px] text-amber-200/90 text-left">
                  진세노사이드 주요 유효 성분(Rg1, Rb1, Rg3)을 온전히 보존하여 활력 증진 및 피로 회복 지원.
                </div>
              )}
            </div>

            {/* Photo 8: Cheerful Model with Cold Glass (image_0ab9819c.png) */}
            <figure className="relative m-0 rounded-2xl overflow-hidden mt-4 border border-slate-700 shadow-md bg-slate-800">
              <img
                src="/assets/aistudio/image_0ab9819c.png"
                alt="Thưởng thức hương vị tươi mát, ngọt dịu giàu Saponin 150mg"
                className="w-full h-auto block object-cover"
              />
              <figcaption className="p-3 bg-slate-950/90 text-center text-xs md:text-sm font-semibold text-amber-300">
                🍯 150mg Saponin tự nhiên – Hương vị ngọt thanh mát lành, sảng khoái từng ngụm
              </figcaption>
            </figure>
          </section>

          {/* Why Powder Section */}
          <section className="p-6 md:p-8 border-b border-slate-200/60 text-center">
            <span className="text-xs font-bold text-orange-500 tracking-wider uppercase">
              POWDER TYPE
            </span>
            <h2 className="text-xl md:text-2xl font-bold text-slate-900 mt-1 mb-4">
              Tại sao lại làm dạng bột hòa tan?
            </h2>
            {showKorean && (
              <p className="text-xs text-orange-600 -mt-2 mb-4">
                왜 티백이 아닌 분말 스틱 타입일까요?
              </p>
            )}

            <div className="space-y-2 text-xs md:text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
              <p className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                ❌ Không lo ngại hormone môi trường từ túi lọc!
                {showKorean && <span className="block text-[11px] text-slate-400 mt-0.5">티백 미세플라스틱/환경호르몬 걱정 NO</span>}
              </p>
              <p className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                ⚡ Không cần mất thời gian hãm trà lâu!
                {showKorean && <span className="block text-[11px] text-slate-400 mt-0.5">우려내는 지루한 대기 시간 제로</span>}
              </p>
              <p className="bg-orange-50/70 p-3 rounded-lg border border-orange-200/70 text-slate-800">
                <strong className="text-orange-600">Tỷ lệ hấp thụ cao vượt trội</strong> do dưỡng chất hòa tan hoàn toàn trong nước, giúp cơ thể hấp thụ an toàn và hiệu quả nhất.
                {showKorean && <span className="block text-[11px] text-orange-800 mt-0.5">물에 즉시 녹아 영양 성분 체내 흡수율 극대화</span>}
              </p>
            </div>
          </section>

          {/* Recommended For & Unboxed Gift Set */}
          <section className="p-6 md:p-8 bg-amber-50/40 border-b border-orange-100">
            <h2 className="text-xl md:text-2xl font-bold text-center text-orange-700 mb-4">
              Dành Cho Những Ai?
            </h2>
            {showKorean && (
              <p className="text-center text-xs text-orange-600 -mt-2 mb-4">
                이런 분들께 적극 추천합니다!
              </p>
            )}

            <ul className="space-y-2.5 mb-6">
              {[
                { vi: 'Người ngại vị đắng gắt của nhân sâm truyền thống', kr: '전통 인삼의 쓴맛이 부담스러운 분' },
                { vi: 'Người đang tìm kiếm thức uống thay thế Cà phê tốt cho sức khỏe', kr: '커피 대신 마실 건강한 음료를 찾는 분' },
                { vi: 'Người muốn bổ sung thức uống ít/không chứa Caffeine', kr: '카페인 부담 없이 편안하게 즐기고 싶은 분' },
                { vi: 'Học sinh, sinh viên, người đi làm cần duy trì sự tỉnh táo & thể lực', kr: '수험생, 직장인 등 집중력과 활력이 필요한 분' },
                { vi: 'Người hay đi công tác, du lịch, thức khuya mệt mỏi', kr: '출장, 야근 등으로 피로가 누적된 분' }
              ].map((item, idx) => (
                <li key={idx} className="flex items-center gap-2.5 bg-white p-3 rounded-xl border border-orange-100 shadow-2xs">
                  <div className="w-5 h-5 rounded-full bg-orange-500 text-white flex items-center justify-center shrink-0 text-xs font-bold">
                    ✓
                  </div>
                  <div className="text-xs md:text-sm text-slate-800">
                    <span className="font-medium">{item.vi}</span>
                    {showKorean && (
                      <span className="block text-[11px] text-slate-400">↳ {item.kr}</span>
                    )}
                  </div>
                </li>
              ))}
            </ul>

            {/* Photo 9: Open Gift Box Gold Tray (image_092c703e.png) */}
            <figure className="relative m-0 rounded-2xl overflow-hidden mb-6 border border-amber-200 shadow-md bg-white">
              <img
                src="/assets/aistudio/image_092c703e.png"
                alt="Hộp quà mở ra với khay vàng kim sang trọng đựng 3 gói trà 귀한생"
                className="w-full h-auto block object-cover"
              />
              <figcaption className="p-3.5 bg-white text-center text-xs md:text-sm font-semibold text-slate-800 border-t border-slate-100 flex items-center justify-between">
                <span>🎁 Món quà sức khỏe thượng hạng dành tặng gia đình & đối tác</span>
                {showKorean && <span className="text-[11px] text-orange-600 font-normal">고급 골드 트레이 선물 패키지</span>}
              </figcaption>
            </figure>

            {/* Photo 10: Refreshing Iced Tea Cheek Model (image_02f52918.png) */}
            <figure className="relative m-0 rounded-2xl overflow-hidden mb-5 bg-white border border-slate-200 shadow-sm">
              <img
                src="/assets/aistudio/image_02f52918.png"
                alt="Thưởng thức ly trà nhân sâm mát lạnh sảng khoái mùa hè"
                className="w-full h-auto block object-cover"
              />
              <figcaption className="p-3 bg-white text-center text-xs md:text-sm font-semibold text-slate-800 border-t border-slate-100 flex items-center justify-between">
                <span>🧊 Mùa hè sảng khoái với trà nhân sâm đá mát lạnh</span>
                {showKorean && <span className="text-[10px] text-orange-600 font-normal">시원한 여름 아이스 레시피</span>}
              </figcaption>
            </figure>

            {/* Drinking Tip Box */}
            <div className="bg-amber-100/60 border-2 border-dashed border-orange-300 rounded-2xl p-5 text-center">
              <h3 className="text-base font-bold text-orange-800 mb-2 flex items-center justify-center gap-1.5">
                <span>💡 Mẹo Thưởng Thức Ngon Nhất (Tip)</span>
              </h3>
              <div className="space-y-1.5 text-xs md:text-sm text-slate-700">
                <p>
                  <strong>🔥 Uống Nóng:</strong> Pha 1 gói với 70ml nước ấm.
                  {showKorean && <span className="block text-[11px] text-slate-500">따뜻하게: 1포 + 따뜻한 물 70ml</span>}
                </p>
                <p>
                  <strong>🧊 Uống Lạnh:</strong> Pha 2~3 gói với 200ml nước đá lạnh.
                  {showKorean && <span className="block text-[11px] text-slate-500">시원하게: 2~3포 + 시원한 얼음물 200ml</span>}
                </p>
              </div>
            </div>
          </section>

          {/* FAQ Section */}
          <section className="p-6 md:p-8 border-b border-slate-200/60">
            <div className="text-center mb-5">
              <span className="text-xs font-bold text-orange-500 tracking-wider uppercase">
                QUESTIONS & ANSWERS
              </span>
              <h2 className="text-xl md:text-2xl font-bold text-slate-900 mt-1 mb-1">
                Câu Hỏi Thường Gặp (FAQ)
              </h2>
              {showKorean && (
                <p className="text-xs text-slate-500">
                  자주 묻는 질문과 답변
                </p>
              )}
            </div>

            <div className="space-y-3">
              {faqs.map((faq, idx) => {
                const isOpen = openFaq === idx;
                return (
                  <div
                    key={idx}
                    className="bg-slate-50 border border-slate-200/70 rounded-xl overflow-hidden transition-all"
                  >
                    <button
                      type="button"
                      onClick={() => toggleFaq(idx)}
                      className="w-full p-4 text-left flex items-start justify-between gap-3 hover:bg-slate-100/70 transition-colors"
                    >
                      <div>
                        <div className="text-xs md:text-sm font-bold text-orange-800">
                          Q. {faq.q}
                        </div>
                        {showKorean && faq.qKr && (
                          <div className="text-[11px] text-slate-400 mt-0.5">
                            ↳ {faq.qKr}
                          </div>
                        )}
                      </div>
                      <ChevronDown
                        className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-200 ${
                          isOpen ? 'rotate-180 text-orange-600' : ''
                        }`}
                      />
                    </button>
                    {isOpen && (
                      <div className="px-4 pb-4 pt-1 text-xs md:text-sm text-slate-600 border-t border-slate-200/40 leading-relaxed bg-white/60">
                        <p>{faq.a}</p>
                        {showKorean && faq.aKr && (
                          <p className="text-[11px] text-slate-400 mt-1.5 pt-1.5 border-t border-slate-100">
                            {faq.aKr}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>

          {/* Sticky CTA Bar */}
          <div className="sticky bottom-0 bg-white/95 backdrop-blur-md p-4 border-t border-slate-200 shadow-lg text-center z-40">
            <button
              type="button"
              onClick={() => setIsModalOpen(true)}
              className="w-full bg-[#f3722c] hover:bg-[#d9480f] text-white font-bold text-base md:text-lg py-3.5 px-6 rounded-xl shadow-md transition-all active:scale-[0.99] flex items-center justify-center gap-2"
            >
              <Gift className="w-5 h-5" />
              <span>Đặt Hàng Ngay / Nhận Tư Vấn</span>
            </button>
            <div className="flex items-center justify-center gap-4 mt-2 text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Chính hãng 100% Hàn Quốc
              </span>
              <span>·</span>
              <span>Giao hàng toàn quốc</span>
            </div>
          </div>
        </div>
      </main>

      {/* Interactive Order & Consultation Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden relative animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-orange-500 to-amber-500 text-white p-5 flex items-center justify-between">
              <div>
                <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full font-medium">
                  Tư Vấn & Đặt Hàng
                </span>
                <h3 className="text-lg font-bold mt-1">Trà Nhân Sâm Gwi-Han-Saeng</h3>
                <p className="text-xs text-amber-100">귀한생 인삼차 주문 및 무료 상담 신청</p>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            {orderSubmitted ? (
              <div className="p-8 text-center space-y-3">
                <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-lg font-bold text-slate-800">
                  Đăng Ký Thành Công!
                </h4>
                <p className="text-sm text-slate-600">
                  Cảm ơn bạn! Chuyên viên chăm sóc khách hàng của Gwi-Han-Saeng sẽ liên hệ lại trong vòng 15 phút.
                </p>
                <p className="text-xs text-slate-400">
                  (신청이 완료되었습니다. 담당자가 곧 연락드리겠습니다.)
                </p>
              </div>
            ) : (
              <form onSubmit={handleOrderSubmit} className="p-5 space-y-4">
                {/* Product Selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                    Chọn Sản Phẩm / Dòng Quan Tâm
                  </label>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {[
                      { id: 'combo-3', name: 'Combo 3 Hộp Quà Tặng (Hot)', price: 'Ưu đãi đặc biệt' },
                      { id: 'energy', name: '01. Energy Charge (30 gói)', price: 'Miễn Dịch' },
                      { id: 'core', name: '02. Core Fit (30 gói)', price: 'Sức Mạnh' },
                      { id: 'beauty', name: '03. Inner Beauty (30 gói)', price: 'Làn Da' }
                    ].map((prod) => (
                      <button
                        key={prod.id}
                        type="button"
                        onClick={() => setSelectedProduct(prod.id)}
                        className={`p-2.5 rounded-xl border text-left transition-all ${
                          selectedProduct === prod.id
                            ? 'border-orange-500 bg-orange-50/80 text-orange-950 font-semibold'
                            : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <div className="font-medium truncate">{prod.name}</div>
                        <div className="text-[10px] text-orange-600 mt-0.5">{prod.price}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Form fields */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Họ và Tên (성함) *
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      required
                      placeholder="Nguyễn Văn A"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Số Điện Thoại (연락처) *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="tel"
                      required
                      placeholder="0912 345 678"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Địa Chỉ Giao Hàng / Tỉnh Thành (배송 주소)
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      placeholder="Số nhà, Quận/Huyện, Tỉnh/TP"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                  </div>
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  className="w-full bg-[#f3722c] hover:bg-[#d9480f] text-white font-bold py-3 rounded-xl transition-all shadow-md flex items-center justify-center gap-2 mt-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Xác Nhận Đặt Hàng / Nhận Tư Vấn</span>
                </button>
                <p className="text-[11px] text-center text-slate-400">
                  Thông tin của bạn được bảo mật tuyệt đối 100%.
                </p>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
